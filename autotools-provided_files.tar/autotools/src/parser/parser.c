#include "parser.h"

#include <stdio.h>

#include "lexer/lexer.h"

void print_parser()
{
    print_lexer();
    printf("parser !!!\n");
}
