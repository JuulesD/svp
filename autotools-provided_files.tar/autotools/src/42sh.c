#include "ast/ast.h"

int main(void)
{
    print_ast();
    return 0;
}
