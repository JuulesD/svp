#ifndef LEXER_H
#define LEXER_H

void print_lexer();

#endif /* ! LEXER_H */
