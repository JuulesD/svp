#include "lexer.h"

#include <stdio.h>

void print_lexer()
{
    puts("Vive les lexer");
}
