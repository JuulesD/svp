#include "ast.h"

#include <stdio.h>

#include "parser/parser.h"

void print_ast()
{
    printf("ast !!!\n");
    print_parser();
}
