#ifndef AST_H
#define AST_H

void print_ast();

#endif /* ! AST_H */
